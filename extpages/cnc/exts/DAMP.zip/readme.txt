So maybe you just want to include the bit at the end:
DAMP uses the OggVorbis music library
OggVorbis© 2003, Xiph.Org Foundation
The libraries and SDKs are released under a BSD-like open source license.
If you would like more information go to http://www.vorbis.com/